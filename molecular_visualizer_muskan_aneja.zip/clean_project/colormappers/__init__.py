# Color mapping module
