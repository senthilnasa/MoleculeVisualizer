#!/usr/bin/env python

# VTK and Rendering Imports
import vtkmodules.vtkRenderingOpenGL2
from vtkmodules.vtkCommonColor import vtkNamedColors
from vtkmodules.vtkCommonCore import vtkMinimalStandardRandomSequence
from vtkmodules.vtkFiltersSources import vtkSphereSource
from vtkmodules.vtkInteractionStyle import vtkInteractorStyleTrackballCamera
from vtkmodules.vtkRenderingCore import (
    vtkActor,
    vtkPolyDataMapper,
    vtkPropPicker,
    vtkProperty,
    vtkRenderWindow,
    vtkRenderWindowInteractor,
    vtkRenderer
)

# PDB Parsing Imports
from Bio.PDB import PDBParser

colors = vtkNamedColors()
NUMBER_OF_SPHERES = 10

# -----------------------------------------------------------------------------
# Class for Picking and Highlighting
# -----------------------------------------------------------------------------
class MouseInteractorHighLightActor(vtkInteractorStyleTrackballCamera):
    def __init__(self, parent=None):
        self.AddObserver("LeftButtonPressEvent", self.leftButtonPressEvent)
        self.LastPickedActor = None
        self.LastPickedProperty = vtkProperty()

    def leftButtonPressEvent(self, obj, event):
        clickPos = self.GetInteractor().GetEventPosition()
        picker = vtkPropPicker()
        picker.Pick(clickPos[0], clickPos[1], 0, self.GetDefaultRenderer())

        self.NewPickedActor = picker.GetActor()

        if self.NewPickedActor:
            if self.LastPickedActor:
                self.LastPickedActor.GetProperty().DeepCopy(self.LastPickedProperty)

            self.LastPickedProperty.DeepCopy(self.NewPickedActor.GetProperty())
            self.NewPickedActor.GetProperty().SetColor(colors.GetColor3d('Red'))
            self.NewPickedActor.GetProperty().SetDiffuse(1.0)
            self.NewPickedActor.GetProperty().SetSpecular(0.0)
            self.NewPickedActor.GetProperty().EdgeVisibilityOn()

            self.LastPickedActor = self.NewPickedActor

        self.OnLeftButtonDown()
        return

# -----------------------------------------------------------------------------
# PDB Utility: Extract Atom, Residue, and B-Factor Data
# -----------------------------------------------------------------------------
def extract_atom_residue_bfactor_data(pdb_path):
    parser = PDBParser(QUIET=True)
    structure = parser.get_structure("molecule", pdb_path)

    atoms_data = []
    residues_data = []
    b_factors = []

    for model in structure:
        for chain in model:
            for residue in chain:
                res_name = residue.get_resname()
                chain_id = chain.id
                residues_data.append((res_name, chain_id))
                for atom in residue:
                    atom_name = atom.get_name()
                    atom_type = atom.element
                    coordinates = atom.get_coord()
                    b_factor = atom.get_bfactor()

                    atoms_data.append((atom_name, res_name, atom_type, coordinates, b_factor))
                    b_factors.append(b_factor)

    return atoms_data, residues_data, b_factors

# -----------------------------------------------------------------------------
# Main VTK Setup
# -----------------------------------------------------------------------------
def main():
    renderer = vtkRenderer()
    renderer.SetBackground(colors.GetColor3d('SteelBlue'))

    renwin = vtkRenderWindow()
    renwin.AddRenderer(renderer)
    renwin.SetSize(800, 600)
    renwin.SetWindowName('Highlight Picked Sphere + PDB Extractor')

    interactor = vtkRenderWindowInteractor()
    interactor.SetRenderWindow(renwin)

    style = MouseInteractorHighLightActor()
    style.SetDefaultRenderer(renderer)
    interactor.SetInteractorStyle(style)

    randomSequence = vtkMinimalStandardRandomSequence()
    randomSequence.SetSeed(8775070)

    for i in range(NUMBER_OF_SPHERES):
        source = vtkSphereSource()

        x = randomSequence.GetRangeValue(-5.0, 5.0)
        randomSequence.Next()
        y = randomSequence.GetRangeValue(-5.0, 5.0)
        randomSequence.Next()
        z = randomSequence.GetRangeValue(-5.0, 5.0)
        randomSequence.Next()
        radius = randomSequence.GetRangeValue(0.5, 1.0)
        randomSequence.Next()

        source.SetRadius(radius)
        source.SetCenter(x, y, z)
        source.SetPhiResolution(11)
        source.SetThetaResolution(21)

        mapper = vtkPolyDataMapper()
        mapper.SetInputConnection(source.GetOutputPort())
        actor = vtkActor()
        actor.SetMapper(mapper)

        r = randomSequence.GetRangeValue(0.4, 1.0)
        randomSequence.Next()
        g = randomSequence.GetRangeValue(0.4, 1.0)
        randomSequence.Next()
        b = randomSequence.GetRangeValue(0.4, 1.0)
        randomSequence.Next()

        actor.GetProperty().SetDiffuseColor(r, g, b)
        actor.GetProperty().SetDiffuse(.8)
        actor.GetProperty().SetSpecular(.5)
        actor.GetProperty().SetSpecularColor(colors.GetColor3d('White'))
        actor.GetProperty().SetSpecularPower(30.0)

        renderer.AddActor(actor)

    interactor.Initialize()
    renwin.Render()
    interactor.Start()

# -----------------------------------------------------------------------------
if __name__ == '__main__':
    main()
    # Uncomment this line and set a path to test PDB data extraction
    atoms, residues, b_factors = extract_atom_residue_bfactor_data("path/to/your/file.pdb")
    print(atoms[:5])  # Print first 5 atoms for inspection
