from trame.app import get_server
from trame.ui.vuetify import SinglePageWithDrawerLayout
from trame.widgets import vtk, vuetify

import os
import tempfile

from vtkmodules.vtkIOChemistry import vtkPDBReader
from vtkmodules.vtkRenderingCore import (
    vtkActor,
    vtkPolyDataMapper,
    vtkRenderer,
    vtkRenderWindow,
    vtkRenderWindowInteractor
)
from vtkmodules.vtkCommonDataModel import vtkMolecule
from vtkmodules.vtkDomainsChemistry import vtkMoleculeMapper
from vtkmodules.vtkDomainsChemistry import vtkProteinRibbonFilter
from vtkmodules.vtkFiltersSources import vtkSphereSource
from vtkmodules.vtkFiltersCore import vtkTubeFilter
from vtkmodules.vtkInteractionStyle import vtkInteractorStyleTrackballCamera
from vtkmodules.vtkCommonExecutionModel import vtkMoleculeAlgorithm
# ---------------------------------------------------------------------
# VTK Pipeline Setup (without default file loading)
# ---------------------------------------------------------------------
# Create a renderer and render window
renderer = vtkRenderer()
renderWindow = vtkRenderWindow()
renderWindow.AddRenderer(renderer)

renderWindowInteractor = vtkRenderWindowInteractor()
renderWindowInteractor.SetRenderWindow(renderWindow)

# Set up the camera interactor style
interactor_style = vtkInteractorStyleTrackballCamera()
renderWindowInteractor.SetInteractorStyle(interactor_style)

# Create a PDB reader
pdb_reader = vtkPDBReader()

# ✅ FIX: Convert PDBReader Output to vtkMolecule
molecule_converter = vtkMolecule()
molecule_converter.DeepCopy(pdb_reader.GetOutputPort())

# Create an empty molecule object and mapper (to be updated later)
molecule = vtkMolecule()
molecule_mapper = vtkMoleculeMapper()
molecule_mapper.SetInputConnection(molecule_converter.GetOutputPort())



molecule_actor = vtkActor()
molecule_actor.SetMapper(molecule_mapper)


# Get Output Data
molecule = vtkMolecule()
molecule.DeepCopy(molecule_converter.GetOutput())    # Ensures proper molecule data usage

ribbon_filter = vtkProteinRibbonFilter()
ribbon_filter.SetInputConnection(pdb_reader.GetOutputPort())  # Proper connection
ribbon_mapper = vtkPolyDataMapper()
ribbon_mapper.SetInputConnection(ribbon_filter.GetOutputPort())

ribbon_actor = vtkActor()
ribbon_actor.SetMapper(ribbon_mapper)

# Define atom and bond representations
atom_mapper, atom_actor = None, None
bond_mapper, bond_actor = None, None
import os
import vtk
import numpy as np
from vtkmodules.vtkIOChemistry import vtkPDBReader
from vtkmodules.vtkCommonDataModel import vtkDataObject, vtkPolyData
from vtkmodules.vtkCommonCore import vtkPoints
from vtkmodules.vtkRenderingCore import (
    vtkActor, vtkPolyDataMapper, vtkRenderer, vtkRenderWindow, vtkRenderWindowInteractor
)
from vtkmodules.vtkCommonDataModel import vtkMolecule
from vtkmodules.vtkDomainsChemistry import vtkMoleculeMapper
from vtkmodules.vtkDomainsChemistry import vtkProteinRibbonFilter
from vtkmodules.vtkFiltersSources import vtkSphereSource
from vtkmodules.vtkFiltersCore import vtkTubeFilter
from vtkmodules.vtkInteractionStyle import vtkInteractorStyleTrackballCamera
from vtkmodules.vtkCommonExecutionModel import vtkMoleculeAlgorithm
from trame.app import get_server
from trame.ui.vuetify import SinglePageLayout
from trame.widgets import vtk, vuetify, trame
from vtkmodules.vtkInteractionStyle import vtkInteractorStyleTrackballCamera
from vtk import vtkCellArray, vtkLine, vtkTubeFilter, vtkSphereSource, vtkGlyph3D
from Bio.PDB import PDBParser
from trame.app import get_server
from trame.ui.vuetify import SinglePageWithDrawerLayout
from trame.widgets import vtk, vuetify
# ------------------------------
# Helper Functions for Visualization
# ------------------------------

def extract_atom_data(structure):
    """ Extract atom positions and atom map from the PDB structure. """
    points = vtkPoints()
    atom_map = {}
    atom_types = []  # Store atom types
    atom_ids = []    # Store atom ids
    i = 0
    for model in structure:
        for chain in model:
            for residue in chain:
                for atom in residue:
                    pos = atom.get_coord()
                    points.InsertNextPoint(pos[0], pos[1], pos[2])
                    atom_map[atom] = i
                    atom_types.append(atom.get_name())  # Add atom type
                    atom_ids.append(i)  # Use atom index as ID
                    i += 1
    return points, atom_map, atom_types, atom_ids


def create_atom_representation(points):
    """ Create spheres to represent atoms. """
    print("Creating atom representation...")
    resolution = 12
    glyph_source = vtkSphereSource()
    glyph_source.SetRadius(0.25)
    glyph_source.SetThetaResolution(resolution)
    glyph_source.SetPhiResolution(resolution)

    glyphs = vtkGlyph3D()
    glyphs.SetSourceConnection(glyph_source.GetOutputPort())
    glyphs.SetScaleFactor(1.0)
    glyphs.SetColorModeToColorByScalar()
    glyphs.OrientOn()

    glyphs.SetInputData(vtkPolyData())
    glyphs.GetInput().SetPoints(points)
    glyphs.Update()
    print("Atom representation created.")

    atom_mapper = vtkPolyDataMapper()
    atom_mapper.SetInputConnection(glyphs.GetOutputPort())

    atom_actor = vtkActor()
    atom_actor.SetMapper(atom_mapper)
    atom_actor.GetProperty().SetColor(1, 0, 0)  # Red atoms
    return atom_mapper, atom_actor

def create_bond_representation(atom_map, points):
    """ Create bonds using lines and tube filter for visualization. """
    print("Creating bond representation...")
    lines = vtkCellArray()
    bond_threshold = 1.6
    atom_list = list(atom_map.keys())
    for i, atom1 in enumerate(atom_list):
        for j, atom2 in enumerate(atom_list[i+1:], start=i+1):
            distance = np.linalg.norm(atom1.coord - atom2.coord)
            if distance < bond_threshold:
                line = vtkLine()
                line.GetPointIds().SetId(0, atom_map[atom1])
                line.GetPointIds().SetId(1, atom_map[atom2])
                lines.InsertNextCell(line)

    bonds_polydata = vtkPolyData()
    bonds_polydata.SetPoints(points)
    bonds_polydata.SetLines(lines)

    tube_filter = vtkTubeFilter()
    tube_filter.SetInputData(bonds_polydata)
    tube_filter.SetRadius(0.2)
    tube_filter.SetNumberOfSides(12)
    tube_filter.Update()
    print("Bond representation created.")

    bond_mapper = vtkPolyDataMapper()
    bond_mapper.SetInputConnection(tube_filter.GetOutputPort())

    bond_actor = vtkActor()
    bond_actor.SetMapper(bond_mapper)
    bond_actor.GetProperty().SetColor(1, 1, 1)  # White bonds

    return bond_mapper, bond_actor

def create_ribbon_representation(atom_map, points, atom_types, atom_ids):
    """ Create ribbon representation for the protein backbone. """
    ribbon_polydata = vtkPolyData()
    ribbon_polydata.SetPoints(points)
    ribbon_polydata.GetPointData().SetScalars(atom_types)  # Set atom types

    # Initialize the ribbon filter
    ribbon_filter = vtkProteinRibbonFilter()
    ribbon_filter.SetInputData(ribbon_polydata)  # Using atom positions as input data
    ribbon_filter.SetAtomIds(atom_ids)  # Set atom IDs
    ribbon_filter.Update()

    ribbon_mapper = vtkPolyDataMapper()
    ribbon_mapper.SetInputConnection(ribbon_filter.GetOutputPort())

    ribbon_actor = vtkActor()
    ribbon_actor.SetMapper(ribbon_mapper)
    ribbon_actor.GetProperty().SetColor(0, 1, 0)  # Green ribbons

    return ribbon_mapper, ribbon_actor


# ------------------------------
# Load PDB File and Create Representation
# ------------------------------

def load_pdb(pdb_path):
    """ Load the PDB file and create visualization. """
    print(f"Loading PDB file from {pdb_path}...")
    parser = PDBParser(QUIET=True)
    structure = parser.get_structure("molecule", pdb_path)

    # Extract atom data and correctly unpack the values
    points, atom_map, atom_types, atom_ids = extract_atom_data(structure)

    # Create visual representations for atoms, bonds, and ribbons
    atom_mapper, atom_actor = create_atom_representation(points)
    bond_mapper, bond_actor = create_bond_representation(atom_map, points)
    ribbon_mapper, ribbon_actor = create_ribbon_representation(atom_map, points, atom_types, atom_ids)

    print("PDB file loaded and representations created.")
    return atom_mapper, atom_actor, bond_mapper, bond_actor, ribbon_mapper, ribbon_actor, structure

# ------------------------------
# Mini Test Case for PDB Loading
# ------------------------------

def test_load_pdb():
    pdb_path = r"C:\Users\muska\Downloads\ProjectCapstone\Cap\data1\1bna.pdb"  # Example file path
    try:
        atom_mapper, atom_actor, bond_mapper, bond_actor, ribbon_mapper, ribbon_actor, structure = load_pdb(pdb_path)
        print("PDB loading test passed.")
    except Exception as e:
        print(f"PDB loading test failed: {e}")

# ------------------------------
# Run the Test Case
# ------------------------------

if __name__ == "__main__":
    test_load_pdb()


# ---------------------------------------------------------------------
# Trame Server and UI
# ---------------------------------------------------------------------
server = get_server(client_type="vue2")
state, ctrl = server.state, server.controller

state.change("pdb_file")(update_pdb_file)


# Default representation mode
state.representation_mode = "Atoms"
state.change("representation_mode")(lambda mode=None, **_: update_representation(mode or "Atoms"))


state.change("pdb_file")(update_pdb_file)

# Default representation mode
state.representation_mode = "Atoms"
state.change("representation_mode")(lambda mode=None, **_: update_representation(mode or "Atoms"))

# ✅ FIX: Ensure update_representation() is called at startup
update_representation(state.representation_mode)


with SinglePageWithDrawerLayout(server) as layout:
    layout.title.set_text("PDB Viewer")

    with layout.toolbar:
        vuetify.VFileInput(
            v_model=("pdb_file", None),
            label="Upload PDB File",
            accept=".pdb",
            dense=True,
            hide_details=True,
        )
    
    with layout.drawer:
        vuetify.VSelect(
            v_model=("representation_mode", "Atoms"),
            items=([
                {"text": "Atoms", "value": "Atoms"},
                {"text": "Ball & Stick", "value": "Ball & Stick"},
                {"text": "Ribbon", "value": "Ribbon"},
            ]),
            label="Molecular Representation",
            hide_details=True,
            dense=True,
            outlined=True,
            classes="pt-1",
        )


    with layout.content:
        with vuetify.VContainer(fluid=True, classes="pa-0 fill-height"):
            view = vtk.VtkLocalView(renderWindow)
            ctrl.view_update = view.update  # ✅ Ensure this is set before calling view updates
            ctrl.view_reset_camera = view.reset_camera

# ✅ FIX: Call update_representation only after UI is initialized
update_representation(state.representation_mode)

if __name__ == "__main__":
    server.start()
