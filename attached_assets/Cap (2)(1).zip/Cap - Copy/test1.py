import vtk

# Path to your PDB file
pdb_path = r"C:\Users\muska\Downloads\ProjectCapstone\Cap\data1\3nir.pdb"

# Reader
reader = vtk.vtkPDBReader()
reader.SetFileName(pdb_path)
reader.Update()

# Molecule Mapper
mapper = vtk.vtkMoleculeMapper()
mapper.SetInputConnection(reader.GetOutputPort())
mapper.UseBallAndStickSettings()  # Sets atom spheres + sticks for bonds

# Actor
actor = vtk.vtkActor()
actor.SetMapper(mapper)

# Renderer, render window, interactor
renderer = vtk.vtkRenderer()
render_window = vtk.vtkRenderWindow()
render_window.AddRenderer(renderer)
interactor = vtk.vtkRenderWindowInteractor()
interactor.SetRenderWindow(render_window)

renderer.AddActor(actor)
renderer.SetBackground(0.1, 0.1, 0.2)
render_window.SetSize(800, 600)

# Picker
picker = vtk.vtkPropPicker()

def click_callback(obj, event):
    x, y = interactor.GetEventPosition()
    if picker.Pick(x, y, 0, renderer):
        picked_pos = picker.GetPickPosition()
        print(f"Picked atom at world coordinates: {picked_pos}")

# Add observer
interactor.AddObserver("LeftButtonPressEvent", click_callback)

# Start
render_window.Render()
interactor.Initialize()
interactor.Start()
