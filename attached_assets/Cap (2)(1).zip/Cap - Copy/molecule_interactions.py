import numpy as np

def select_atoms_and_calculate_distance(atoms_data):
    """Select two atoms and calculate their distance."""
    if len(atoms_data) < 2:
        print("Not enough atoms to measure distance.")
        return

    # Example: Selecting first two atoms
    atom1 = atoms_data[0]
    atom2 = atoms_data[1]

    # Extracting coordinates
    coord1 = np.array(atom1["coordinates"])
    coord2 = np.array(atom2["coordinates"])

    # Calculating distance
    distance = np.linalg.norm(coord1 - coord2)

    # Displaying results
    print(f"Selected Atoms: {atom1['atom_name']} ({atom1['residue_name']}) and "
          f"{atom2['atom_name']} ({atom2['residue_name']})")
    print(f"Distance: {distance:.2f} Å")
