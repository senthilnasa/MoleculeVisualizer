#!/usr/bin/env python

# A simple script to demonstrate the vtkCutter function

# noinspection PyUnresolvedReferences
import vtkmodules.vtkInteractionStyleTrackballCamera

# noinspection PyUnresolvedReferences
import vtkmodules.vtkRenderingOpenGL2
from vtkmodules.vtkCommonColor import vtkNamedColors
from vtkmodules.vtkCommonDataModel import vtkPlane
from vtkmodules.vtkFiltersCore import vtkCutter
from vtkmodules.vtkFiltersSources import vtkCubeSource
from vtkmodules.vtkRenderingCore import (
    vtkActor,
    vtkPolyDataMapper,
    vtkRenderWindow,
    vtkRenderWindowInteractor,
    vtkRenderer
)

# Create a cube
cube = vtkCubeSource()
cube.SetXLength(40)
cube.SetYLength(30)
cube.SetZLength(20)
cubeMapper = vtkPolyDataMapper()
cubeMapper.SetInputConnection(cube.GetOutputPort())

# Create a plane to cut
plane = vtkPlane()
plane.SetOrigin(10, 0, 0)  # Set initial position of the plane
plane.SetNormal(1, 0, 0)  # Set initial normal

# Create cutter
cutter = vtkCutter()
cutter.SetCutFunction(plane)
cutter.SetInputConnection(cube.GetOutputPort())
cutter.Update()
cutterMapper = vtkPolyDataMapper()
cutterMapper.SetInputConnection(cutter.GetOutputPort())

# Create cube actor
cubeActor = vtkActor()
cubeActor.SetMapper(cubeMapper)
cubeActor.GetProperty().SetColor(0.0, 1.0, 1.0)  # Set cube color

# Create plane actor
planeActor = vtkActor()
planeActor.SetMapper(cutterMapper)
planeActor.GetProperty().SetColor(1.0, 1.0, 0.0)  # Set plane cut color

# Create renderer and render window
ren = vtkRenderer()
ren.AddActor(cubeActor)
ren.AddActor(planeActor)
ren.SetBackground(0.5, 0.5, 0.5)

renWin = vtkRenderWindow()
renWin.AddRenderer(ren)
renWin.SetSize(600, 600)

# Create interactor
iren = vtkRenderWindowInteractor()
iren.SetRenderWindow(renWin)

# Add custom interactor style to move the plane with mouse input
class PlaneInteractorStyle(vtkInteractorStyleTrackballCamera):
    def __init__(self):
        self.AddObserver("MouseMoveEvent", self.onMouseMove)
        self.plane_origin = [10, 0, 0]  # Initial plane origin

    def onMouseMove(self, obj, event):
        # Update the plane origin based on the mouse position (e.g., on X-axis)
        x, y = self.GetInteractor().GetEventPosition()
        self.plane_origin[0] = x / 10.0  # Example: Move plane along the X-axis
        plane.SetOrigin(self.plane_origin)
        cutter.Update()
        renWin.Render()  # Redraw the scene

# Set the custom interactor style
style = PlaneInteractorStyle()
iren.SetInteractorStyle(style)

# Start the rendering loop
renWin.Render()
iren.Start()