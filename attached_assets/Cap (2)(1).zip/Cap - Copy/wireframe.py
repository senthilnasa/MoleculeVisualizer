
from pathlib import Path

from trame.app import get_server
from trame.ui.vuetify import SinglePageWithDrawerLayout
from trame.widgets import vuetify, html, trame, vtk as vtk_widgets

from vtkmodules.web.utils import mesh as vtk_mesh
from vtkmodules.vtkIOXML import vtkXMLPolyDataReader
from vtkmodules.vtkFiltersGeneral import vtkExtractSelectedFrustum
from vtkmodules.vtkFiltersCore import vtkThreshold

from trame.widgets.vtk import VtkView

from trame.app import get_server
from trame.ui.vuetify import SinglePageWithDrawerLayout
from vtkmodules.vtkFiltersGeneral import vtkExtractSelectedFrustum
from vtkmodules.vtkFiltersCore import vtkThreshold
from pathlib import Path
import os
import tempfile
from vtkmodules.vtkIOChemistry import vtkPDBReader
from vtkmodules.vtkRenderingCore import (
    vtkActor,
    vtkPolyDataMapper,
    vtkRenderer,
    vtkRenderWindow,
    vtkRenderWindowInteractor
    

)


from vtkmodules.vtkCommonDataModel import vtkPlanes
from vtkmodules.vtkFiltersExtraction import vtkExtractGeometry


import numpy as np
from vtkmodules.vtkIOChemistry import vtkPDBReader
from vtkmodules.vtkCommonDataModel import vtkDataObject, vtkPolyData
from vtkmodules.vtkCommonCore import vtkPoints
from vtkmodules.web.utils import mesh as vtk_mesh
from vtkmodules.vtkCommonCore import vtkFloatArray

from vtkmodules.vtkInteractionStyle import vtkInteractorStyleTrackballCamera
from vtk import vtkCellArray, vtkLine, vtkTubeFilter, vtkSphereSource, vtkGlyph3D


# Initialize Trame Server
server = get_server(client_type="vue2")
state = server.state
# -----------------------------------------------------------------------------
# Constants
# -----------------------------------------------------------------------------

atom_data = []
SCALE_P = 0.0001  # Scaling factor for precision adjustments
SCALE_U = 0.01  # Scaling factor for unit adjustments

# Interaction settings for VTK/Trame visualization
VIEW_INTERACT = [
    {"button": 1, "action": "Rotate"},  # Left-click: Rotate
    {"button": 2, "action": "Pan"},  # Middle-click: Pan
    {"button": 3, "action": "Zoom", "scrollEnabled": True},  # Right-click: Zoom (Scroll enabled)
    {"button": 1, "action": "Pan", "alt": True},  # ALT + Left-click: Pan
    {"button": 1, "action": "Zoom", "control": True},  # CTRL + Left-click: Zoom
    {"button": 1, "action": "Pan", "shift": True},  # SHIFT + Left-click: Pan
    {"button": 1, "action": "Roll", "alt": True, "shift": True},  # ALT + SHIFT + Left-click: Roll view
]

# Selection settings for picking atoms or residues
VIEW_SELECT = [{"button": 1, "action": "Select"}]  # Left-click: Select element
state.selected_atom = None  # This can be used to track selected atoms
state.selected_residue = None  # This can be used to track selected residues
state.view_mode = None  # Example for a state variable to track visualization mode

from Bio.PDB import PDBParser



def extract_pdb_properties(pdb_path):
    global pdb_polydata, atom_data
    parser = PDBParser(QUIET=True)
    structure = parser.get_structure("molecule", pdb_path)

    extracted_data = []
    points = vtkPoints()  # Create vtkPoints to store atom coordinates

    point_index = 0  # For indexing each point
    for model in structure:
        for chain in model:
            for residue in chain:
                res_name = residue.get_resname()
                res_id = residue.get_id()[1]  # Residue sequence number

                for atom in residue:
                    atom_name = atom.get_name()
                    atom_type = atom.element
                    b_factor = atom.get_bfactor()
                    occupancy = atom.get_occupancy()
                    coord = atom.get_coord()  # (x, y, z) coordinates
                    
                    # Append atom data
                    extracted_data.append({
                        "atom_name": atom_name,
                        "atom_type": atom_type,
                        "residue_name": res_name,
                        "residue_id": res_id,
                        "b_factor": b_factor,
                        "occupancy": occupancy,
                    })
                    
                    # Add coordinate to points
                    points.InsertNextPoint(coord[0], coord[1], coord[2])

                    point_index += 1

    # Create vtkPolyData for rendering
    polydata = vtkPolyData()
    polydata.SetPoints(points)

    return extracted_data, polydata  # Return both extracted data and polydata


# -----------------------------------------------------------------------------
# Web App setup
# -----------------------------------------------------------------------------
state.trame__title = "PDB Visualization"
state.update(
    {
        # Interaction settings
        "view_interact": VIEW_INTERACT,
        "view_select": VIEW_SELECT,
        
        # Selection tracking
        "selected_atom": None,
        "selected_residue": None,
        "view_mode": None,

        # Picking controls
        "modes": [
            {"value": "hover", "icon": "mdi-magnify"},
            {"value": "click", "icon": "mdi-cursor-default-click-outline"},
            {"value": "select", "icon": "mdi-select-drag"},
        ],
        
        # Picking feedback
        "pickData": None,
        "selectData": None,
        "tooltip": "",
        "coneVisibility": False,
        "pixel_ratio": 2,
        
        # Visualization toggles
        "ball_stick_visible": True,
        "cartoon_visible": False,
        "ribbon_visible": False,

        # Atom and residue data
        "atom_types": [],
        "residues": [],
        "b_factor_range": (None, None),
        "occupancy_range": (None, None),
        
        # UI elements
        "color_mode": "element",  # Can be 'element', 'residue', or 'b-factor'
        "representation": "ball_stick",  # Can be 'ball_stick', 'cartoon', or 'ribbon'
    }
)

# -----------------------------------------------------------------------------
# Callbacks
# -----------------------------------------------------------------------------

@state.change("pickingMode")
def update_picking_mode(pickingMode, **kwargs):
    if pickingMode is None:
        state.update(
            {
                "tooltip": "",
                "tooltipStyle": {"display": "none"},
                "selectedAtom": None,
                "interactorSettings": VIEW_INTERACT,
            }
        )
    else:
        state.interactorSettings = VIEW_SELECT if pickingMode == "select" else VIEW_INTERACT
        state.update(
            {
                "selectedAtom": None,  # Reset selected atom on mode change
                "highlightAtom": None,  # Clear any highlighted atom
                "tooltip": "Click on an atom to select",
                "tooltipStyle": {"display": "block"},
            }
        )
@state.change("selectData")
def update_selection(selectData, **kwargs):
    if not selectData:
        return  # No selection made, exit early

    # Extract the frustum selection data
    frustum_coords = selectData.get("frustum")
    if not frustum_coords:
        return  # No valid frustum data

    # Convert selection coordinates into VTK frustum
    vtk_frustum = vtkPlanes()
    vtk_frustum.SetFrustumPlanes([coord + [1] for coord in frustum_coords])

    # Create extraction filter
    extract = vtkExtractGeometry()
    extract.SetInputData(state.vtk_mesh)  # Assuming state.vtk_mesh is the main dataset
    extract.SetImplicitFunction(vtk_frustum)
    
    # Enable temporary bounding box visualization
    extract.ShowBoundsOn()
    extract.PreserveTopologyOff()
    extract.Update()

    # Store extracted selection in state
    state.frustrum = vtk_mesh(extract.GetOutput())  # Save frustum extraction
    extract.ShowBoundsOff()
    extract.PreserveTopologyOn()

    # Apply a threshold filter if needed
    threshold = vtkExtractGeometry()
    threshold.SetInputData(extract.GetOutput())
    threshold.Update()

    # Update the final selection in state
    state.selection = vtk_mesh(threshold.GetOutput())

    # Reset selection state
    state.selectData = None
    state.pickingMode = None

@state.change("pickData")
def update_tooltip(pickData, pixel_ratio, **kwargs):
    # Ensure `pdb_polydata` and `atom_data` are globally available
    
    state.tooltip = ""
    state.tooltipStyle = {"display": "none"}
    state.coneVisibility = False

    if not pickData:
        return

    world_pos = pickData.get("worldPosition")
    if not world_pos or pdb_polydata is None:
        return

    idx = pdb_polydata.FindPoint(world_pos)  # Find the closest atom in the PDB mesh
    if idx == -1 or idx >= len(atom_data):  # Ensure idx is valid
        return

    # Retrieve Atom Details
    atom_info = atom_data[idx]
    atom_name = atom_info.get("atom_name", "Unknown")
    residue_name = atom_info.get("residue_name", "Unknown")
    atom_type = atom_info.get("atom_type", "N/A")
    b_factor = atom_info.get("b_factor", 0.0)

    # Tooltip messages
    messages = [
        f"Atom: {atom_name} ({atom_type})",
        f"Residue: {residue_name}",
        f"B-Factor: {b_factor:.2f}"
    ]

    # Tooltip Positioning
    display_x, display_y, _ = pickData.get("displayPosition", [0, 0, 0])
    state.coneVisibility = True
    state.tooltip = "\n".join(messages)
    state.tooltipStyle = {
        "position": "absolute",
        "left": f"{(display_x / pixel_ratio) + 10}px",
        "bottom": f"{(display_y / pixel_ratio) + 10}px",
        "zIndex": 10,
        "pointerEvents": "none",
        "background": "rgba(0, 0, 0, 0.75)",
        "color": "white",
        "padding": "5px",
        "borderRadius": "5px",
        "fontSize": "12px",
    }
def load_pdb_file(pdb_path):
    # Initialize PDB Reader
    pdb_reader = vtkPDBReader()
    pdb_reader.SetFileName(pdb_path)
    pdb_reader.Update()  # Read the PDB file
    
    # Retrieve the polydata (structure of atoms and bonds)
    return pdb_reader.GetOutput()
# ------------------------------
# Function to Extract Atom, Residue, and B-Factor Data
# ------------------------------
def extract_atom_residue_bfactor_data(pdb_path):
    """Extracts atom, residue, and B-factor information from a PDB file."""
    parser = PDBParser(QUIET=True)
    structure = parser.get_structure("molecule", pdb_path)

    atoms_data = []  # Will hold atom info: (atom_name, residue_name, atom_type, coordinates, b_factor)
    residues_data = []  # Will hold residue info: (residue_name, chain_id)
    b_factors = []  # Will hold B-factors for each atom

    for model in structure:
        for chain in model:
            for residue in chain:
                for atom in residue:
                    atom_name = atom.get_name()
                    residue_name = atom.get_parent().get_resname()  # Residue name
                    atom_type = atom.element  # Atom type (C, O, N, etc.)
                    coordinates = atom.get_coord()  # Atom coordinates (x, y, z)
                    b_factor = atom.get_bfactor()  # B-factor (temperature factor)

                    # Collect atom data
                    atoms_data.append({
                        "atom_name": atom_name,
                        "residue_name": residue_name,
                        "atom_type": atom_type,
                        "coordinates": coordinates,
                        "b_factor": b_factor
                    })

                    # Collect residue data (skip duplicates for residues)
                    if (residue_name, chain.get_id()) not in residues_data:
                        residues_data.append((residue_name, chain.get_id()))

                    # Collect B-factors
                    b_factors.append(b_factor)

    return atoms_data, residues_data, b_factors

# ------------------------------
# Color Mapping Function
# ------------------------------
def color_atoms_by_type(atom_type):
    """Map atom types to colors."""
    atom_colors = {
        'C': (0.0, 0.0, 0.0),  # Black for Carbon
        'O': (1.0, 0.0, 0.0),  # Red for Oxygen
        'N': (0.0, 0.0, 1.0),  # Blue for Nitrogen
        'H': (1.0, 1.0, 1.0),  # White for Hydrogen
        'S': (1.0, 1.0, 0.0),  # Yellow for Sulfur
        'P': (1.0, 0.5, 0.0)   # Orange for Phosphorus
    }
    return atom_colors.get(atom_type, (0.5, 0.5, 0.5))  # Default grey for unknown elements

# ------------------------------
# VTK Renderer Setup with Color Mapping
# ------------------------------
def setup_vtk_renderer(pdb_path, resolution=12, bond_threshold=1.6):
    """Setup VTK for visualizing the PDB structure with color mapping."""
    parser = PDBParser(QUIET=True)
    structure = parser.get_structure("molecule", pdb_path)

    points = vtkPoints()
    lines = vtkCellArray()
    atom_map = {}
    
    # Create atom spheres
    glyph_source = vtkSphereSource()
    glyph_source.SetRadius(0.25)
    glyph_source.SetThetaResolution(resolution)
    glyph_source.SetPhiResolution(resolution)

    glyphs = vtkGlyph3D()
    glyphs.SetSourceConnection(glyph_source.GetOutputPort())
    glyphs.SetScaleFactor(1.0)
    glyphs.SetColorModeToColorByScalar()
    glyphs.OrientOn()

    # Populate atom positions and color them based on atom type and B-factor
    i = 0
    colors = vtkFloatArray()
    colors.SetNumberOfComponents(3)  # RGB colors for each atom
   

    for model in structure:
        for chain in model:
            for residue in chain:
                for atom in residue:
                    pos = atom.get_coord()
                    points.InsertNextPoint(pos[0], pos[1], pos[2])
                    atom_map[atom] = i
                    
                    # Apply color based on atom type
                    atom_color = color_atoms_by_type(atom.element)
                    colors.InsertNextTuple3(atom_color[0], atom_color[1], atom_color[2])
                    
                    i += 1

    glyphs.SetInputData(vtkPolyData())
    glyphs.GetInput().SetPoints(points)
    glyphs.GetInput().GetPointData().SetScalars(colors)  # Add color to atom points
    glyphs.Update()

    # Atom Mapper
    atom_mapper = vtkPolyDataMapper()
    atom_mapper.SetInputConnection(glyphs.GetOutputPort())
    atom_actor = vtkActor()
    atom_actor.SetMapper(atom_mapper)

    # Create bonds (sticks)
    atom_list = list(atom_map.keys())
    for i, atom1 in enumerate(atom_list):
        for j, atom2 in enumerate(atom_list[i+1:], start=i+1):
            distance = np.linalg.norm(atom1.coord - atom2.coord)
            if distance < bond_threshold:
                line = vtkLine()
                line.GetPointIds().SetId(0, atom_map[atom1])
                line.GetPointIds().SetId(1, atom_map[atom2])
                lines.InsertNextCell(line)

    bonds_polydata = vtkPolyData()
    bonds_polydata.SetPoints(points)
    bonds_polydata.SetLines(lines)

    # Tube Filter for bonds
    tube_filter = vtkTubeFilter()
    tube_filter.SetInputData(bonds_polydata)
    tube_filter.SetRadius(0.2)
    tube_filter.SetNumberOfSides(resolution)
    tube_filter.Update()

    # Bond Mapper
    bond_mapper = vtkPolyDataMapper()
    bond_mapper.SetInputConnection(tube_filter.GetOutputPort())
    bond_actor = vtkActor()
    bond_actor.SetMapper(bond_mapper)
    bond_actor.GetProperty().SetColor(1, 1, 1)  # White bonds

    # Renderer setup
    renderer = vtkRenderer()
    render_window = vtkRenderWindow()
    render_window.AddRenderer(renderer)
    render_window_interactor = vtkRenderWindowInteractor()
    render_window_interactor.SetRenderWindow(render_window)
    render_window_interactor.SetInteractorStyle(vtkInteractorStyleTrackballCamera())

    renderer.SetBackground(0, 0, 0)  # Black background
    renderer.AddActor(atom_actor)
    renderer.AddActor(bond_actor)
    renderer.ResetCamera()

    return render_window, render_window_interactor

# ------------------------------
# Trame UI Setup
# ------------------------------
def setup_trame_ui(render_window):
    """Setup Trame UI to display VTK rendering."""

    # Setting up Trame server UI
    with SinglePageWithDrawerLayout(server) as layout:
        layout.title.set_text("PDB Visualization - Trame")

        with layout.content:
            # Container for UI elements
            with vuetify.VContainer(
                fluid=True, classes="pa-0 fill-height", style="position: relative;"
            ):
                # Tooltip display card
                with vuetify.VCard(
                    style="tooltipStyle", elevation=2, outlined=True
                ):
                    with vuetify.VCardText():
                        html.Pre("{{ tooltip }}")

                # VTK visualization view
                with vtk_widgets.VtkView(
                    ref="view",
                    picking_modes=("[pickingMode]",),
                    interactor_settings=("interactorSettings", VIEW_INTERACT),
                    click="pickData = $event",
                    hover="pickData = $event",
                    select="selectData = $event",
                ):
                    # Geometry representation for Ball & Stick model (f1_mesh)
                    with vtk_widgets.VtkGeometryRepresentation(
                        id="f1",
                        v_if="f1Visible",
                        color_map_preset=("colorMap",),
                        color_data_range=("fieldParameters[field].range",),
                        actor=("{ visibility: f1Visible }",),
                        mapper=(
                            """{
                                colorByArrayName: field,
                                scalarMode: 3,
                                interpolateScalarsBeforeMapping: true,
                                scalarVisibility: field !== 'solid',
                            }""",
                        ),
                    ):
                        vtk_widgets.VtkMesh("f1", dataset=f1_mesh, point_arrays=["p", "U"])

                    # Selection Geometry for visualizing atom selections
                    with vtk_widgets.VtkGeometryRepresentation(
                        id="selection",
                        actor=("{ visibility: !!selection }",),
                        property=(
                            "{ color: [0.99, 0.13, 0.37], representation: 0, pointSize: Math.round(5 * pixel_ratio)}",
                        ),
                    ):
                        vtk_widgets.VtkMesh("selection", state=("selection", None))

                    # Frustum Geometry (for selection box visualization)
                    with vtk_widgets.VtkGeometryRepresentation(
                        id="frustrum",
                        actor=("{ visibility: !!frustrum }",),
                    ):
                        vtk_widgets.VtkMesh("frustrum", state=("frustrum", None))

                    # Pointer (Cone) for visual feedback on interaction
                    with vtk_widgets.VtkGeometryRepresentation(
                        id="pointer",
                        property=("{ color: [1, 0, 0]}",),
                        actor=("{ visibility: coneVisibility }",),
                    ):
                        vtk_widgets.VtkAlgorithm(
                            vtk_class="vtkConeSource",
                            state=("cone", {}),
                        )

    # Return the render window setup, to be used by VTK and Trame
    return render_window
# ------------------------------
# Main Execution
# ------------------------------
if __name__ == "__main__":
    pdb_path = r"C:\Users\muska\Downloads\ProjectCapstone\Cap\data1\3nir.pdb"
    f1_mesh = load_pdb_file(pdb_path)
    # Test data extraction
    atoms_data, residues_data, b_factors = extract_atom_residue_bfactor_data(pdb_path)
    for atom_info in atoms_data[:5]:  # Print first 5 atoms for testing
        print(f"Atom: {atom_info['atom_name']}, Residue: {atom_info['residue_name']}, "
              f"Atom Type: {atom_info['atom_type']}, Coordinates: {atom_info['coordinates']}, "
              f"B-Factor: {atom_info['b_factor']}")
    properties = extract_pdb_properties(pdb_path)
    print(properties)
    pdb_polydata,atom_data = extract_pdb_properties(pdb_path)
    # Setup VTK Rendering
    render_window, render_window_interactor = setup_vtk_renderer(pdb_path)
    
    # Setup Trame UI
    setup_trame_ui(render_window)
    
    # Start Trame server
    server.start() 