import os
import vtk
from vtkmodules.vtkIOChemistry import vtkPDBReader
from vtkmodules.vtkCommonDataModel import vtkDataObject

# ------------------------------
# Function to Extract Data Arrays
# ------------------------------
def extract_data_arrays(reader):
    dataset_arrays = []
    
    # Get PointData and CellData
    fields = [
        (reader.GetOutput().GetPointData(), vtkDataObject.FIELD_ASSOCIATION_POINTS),
        (reader.GetOutput().GetCellData(), vtkDataObject.FIELD_ASSOCIATION_CELLS),
    ]

    for field_data, association in fields:
        for i in range(field_data.GetNumberOfArrays()):
            array = field_data.GetArray(i)
            if array:  # Ensure array is valid
                array_range = array.GetRange() if array.GetNumberOfComponents() == 1 else (0, 1)
                dataset_arrays.append(
                    {
                        "text": array.GetName(),
                        "value": i,
                        "range": list(array_range),
                        "type": association,
                    }
                )
    
    return dataset_arrays

# ------------------------------
# Main Execution for Testing
# ------------------------------
if __name__ == "__main__":
    # Set a sample PDB file path (Replace with an actual PDB file path)
    CURRENT_DIRECTORY = os.path.abspath(os.path.dirname(__file__))
    pdb_file_path = os.path.join(CURRENT_DIRECTORY, r"C:\Users\muska\Downloads\ProjectCapstone\Cap\data1\1bna.pdb")  # Replace with a valid file
    
    if not os.path.exists(pdb_file_path):
        print(f"Error: File '{pdb_file_path}' not found. Please provide a valid PDB file.")
    else:
        # Load PDB file
        pdb_reader = vtkPDBReader()
        pdb_reader.SetFileName(pdb_file_path)
        pdb_reader.Update()

        # Extract available data arrays
        available_arrays = extract_data_arrays(pdb_reader)

        # Print extracted arrays for debugging
        print("\nExtracted Data Arrays:")
        for array in available_arrays:
            print(array)
